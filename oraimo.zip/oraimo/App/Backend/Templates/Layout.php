<!DOCTYPE html>
<!-- #/usr/bin/env html -->
<!-- # coding: utf-8 -->
<!-- # Copyright (c) kitsmass, 2019 -->

<html lang="en">  

<?php include 'Header.php';?>
 <?php include 'Foot.php';?>
   <body >
     <div class="wrapper horizontal-layout-2">

              <?php include 'Navbar.php';?>
          
                <?= $content ?>
          <?php include 'Footer.php';?>
      </div>

     
   </body>
</html>