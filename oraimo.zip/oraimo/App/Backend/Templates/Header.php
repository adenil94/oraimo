<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Oraimo crm</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="/App/Backend/Web/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['/App/Backend/Web/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
  <link rel="stylesheet" href="/Web/css/font-awesome-4.7.0/css/font-awesome.css">

	<link rel="stylesheet" href="/App/Backend/Web/css/bootstrap.min.css">
	<link rel="stylesheet" href="/App/Backend/Web/css/Oraimo.min.css?1">

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="/App/Backend/Web/css/style.css">
</head>