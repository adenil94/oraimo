 <?php
 

class CrmController extends BackController
{
    /**
 * @license Oraimo License
 * @author Andil ADEBIYI <andiladebiyi@gmail.com>
 * @route /GestionMaison
 * @Copyright (c) Oraimo, 2020
 */

  public function executeConnexion(HTTPRequest $request)
  {

  } 

      /**
 * @license Oraimo License
 * @author Andil ADEBIYI <andiladebiyi@gmail.com>
 * @route /crm-admin-oraimo
 * @Copyright (c) Oraimo, 2020
 */
  public function executePageDacceuilArticleTable(HTTPRequest $request)
  {
    
  }
   
 /**
 * @license Oraimo License
 * @author Andil ADEBIYI <andiladebiyi@gmail.com>
 * @route /crm-admin-oraimo/Ajoute-article
 * @Copyright (c) Oraimo, 2020
 */
  public function executePageAjoutArticle(HTTPRequest $request)
  {
    
  }

 } 