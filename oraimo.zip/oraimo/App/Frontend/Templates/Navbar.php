<header id="header" class="header style-04 header-dark">
    <div class="header-top">
        <div class="container">
            <div class="header-top-inner">
                <ul id="menu-top-left-menu" class="oraimolg-nav top-bar-menu">
                    
                </ul>
                <div class="oraimolg-nav top-bar-menu right">
                    <ul class="wpml-menu">
                       
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="header-middle">
        <div class="container">
            <div class="header-middle-inner">
                <div class="header-logo-menu">
                    <div class="block-menu-bar">
                        <a class="menu-bar menu-toggle" href="#">
                            <span></span>
                            <span></span>
                            <span></span>
                        </a>
                    </div>
                    <div class="header-logo">
                        <a href="index-2.html"><img alt="Oraimo" width="150" src="/App/Frontend/Web/images/logo.png" class="logo"></a></div>
                </div>
                <div class="header-search-mid">
                    <div class="header-search">
                        <div class="block-search">
                            <form role="search" method="get"
                                  class="form-search block-search-form oraimolg-live-search-form">
                                <div class="form-content search-box results-search">
                                    <div class="inner">
                                        <input autocomplete="off" class="searchfield txt-livesearch input" name="s"
                                               value="" placeholder="Rechercher ici..." type="text">
                                    </div>
                                </div>
                                <button type="submit" class="btn-submit">
                                    <span class="fa fa-search"></span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="header-control"></div>
            </div>
        </div>
    </div>
    <div class="header-wrap-stick">
        <div class="header-position">
            <div class="header-nav">
                <div class="container">
                    <div class="oraimolg-menu-wapper"></div>
                    <div class="header-nav-inner">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-mobile">

        <div class="header-mobile-mid p-3">
            <div class="header-logo">
                <a href="index-2.html"><img alt="oraimolg"
                                          src="/App/Frontend/Web/images/logo.png"
                                          class="logo"></a></div>
        </div>

    </div>
</header>