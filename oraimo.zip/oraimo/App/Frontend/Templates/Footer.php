<footer id="footer" class="footer style-01">
    <div class="section-010">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>© Copyright 2020 <a href="#">oraimolg</a>. All Rights Reserved.</p>
                </div>
                <div class="col-md-6">

                </div>
            </div>
        </div>
    </div>
</footer>
<div class="footer-device-mobile">
    <div class="wapper">
        <div class="footer-device-mobile-item device-home">

        </div>
        <div class="footer-device-mobile-item device-home device-wishlist">
            <a href="index-2.html">
                    <span class="icon">
                        <i class="fa fa-home" aria-hidden="true"></i>
                    </span>
                Acceuil
            </a>
        </div>
        <div class="footer-device-mobile-item device-home device-cart">
            <a href="my-account.html">
                    <span class="icon">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                Compte
            </a>
        </div>
        <div class="footer-device-mobile-item device-home device-user">

        </div>
    </div>
</div>
<a href="#" class="backtotop active">
    <i class="fa fa-angle-up"></i>
</a>