<!DOCTYPE html>
<!-- #/usr/bin/env html -->
<!-- # coding: utf-8 -->
<!-- # Copyright (c) kitsmass, 2019 -->

<html lang="en">  

<?php include 'head.php';?>
 <?php include 'Foot.php';?>
   <body >


              <?php include 'Navbar.php';?>
          
                <?= $content ?>
          <?php include 'Footer.php';?>


     
   </body>
</html>