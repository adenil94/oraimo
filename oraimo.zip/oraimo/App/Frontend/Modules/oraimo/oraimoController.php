 <?php
 

class oraimoController extends BackController
{
    /**
 * @license Monxwe License
 * @author Andil ADEBIYI <andiladebiyi@gmail.com>
 * @route /GestionMaison
 * @Copyright (c) Monxwe, 2019
 */

  public function executeConnexion(HTTPRequest $request)
  {

  } 

      /**
 * @license Monxwe License
 * @author Andil ADEBIYI <andiladebiyi@gmail.com>
 * @route /GestionMaison/Acceuil
 * @Copyright (c) Monxwe, 2019
 */
  public function executeindex(HTTPRequest $request)
  {
  
  }
      /**
 * @license Monxwe License
 * @author Andil ADEBIYI <andiladebiyi@gmail.com>
 * @route /GestionMaison/Rapport/Maisons
 * @Copyright (c) Monxwe, 2019
 */
  

 } 